%% function for create graph with specified distribution
function Graph=CubeGraph(cube,nLen,nW,Len)

% close all;
tic
%calculate sizes
Nxy=(nLen+1)*(nW+1);
N=Nxy*2;
if cube==0
    N=N+nLen*nW;
end
%create table of nodes links
TabLink=zeros(N,N);
%calculate sizes
L1=Len/nLen;
H1=L1;
W1=L1;
W=W1*nW;
H=H1;
% 
% 
% coord01=0:Len/nLen:Len;
coord1=[];
coord2=[];
coord3=[];


    coord01=[];
    coord02=[];
    coord03=[];

%�����1 ��� �����
for i=1:nW+1
    coord01=[coord01,0:L1:Len];
    coord02=[coord02,ones(1,nLen+1)*W1*(i-1)];
end

% for i=1:nW+1
    coord1=[coord1,coord01,coord01];
    coord2=[coord2,coord02,coord02];
    coord3=[coord3,zeros(1,Nxy),ones(1,Nxy)*H1];
% end






%0 ��� ����������
if cube==0
    coord01=[];
    coord02=[];
    coord03=[];
    for i=1:nW
        coord01=[coord01,L1/2:L1:Len];
        coord02=[coord02,ones(1,nLen)*W1/2*(2*i-1)];
    end
    coord1=[coord1,coord01];
    coord2=[coord2,coord02];
    coord3=[coord3,ones(1,nLen*nW)*H1/2];
else
    
end



%0 ��� ����������
if cube==0
    
for i=1:N
    for j=1:N
        if (abs((sqrt((coord1(i)-coord1(j))^2+ ...
            (coord2(i)-coord2(j))^2+ ...
            (coord3(i)-coord3(j))^2) ...
            -L1)/L1)<0.0001||...
            abs((sqrt((coord1(i)-coord1(j))^2+ ...
            (coord2(i)-coord2(j))^2+ ...
            (coord3(i)-coord3(j))^2) ...
            -L1*sqrt(3)/2)/L1/sqrt(3)*2)<0.0001)&&...
            coord3(i)~=H1/2
            TabLink(i,j)=1;
        end
    end
end




%1 ��� ����������
elseif cube==1
    
    for i=1:N
        for j=1:N
            if (abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1)/L1)<0.0001||...
                    abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1*sqrt(3))/L1/sqrt(3))<0.0001)&&...
                    coord3(i)~=H1/2
                TabLink(i,j)=1;
            end
        end
    end
    
    %2 ��� ����������
elseif cube==2
    
    for i=1:N
        for j=1:N
            if (abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1)/L1)<0.0001||...
                    abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1*sqrt(2))/L1/sqrt(2))<0.0001&&coord1(i)<coord1(j)&&coord3(i)<coord3(j)&&coord2(i)==coord2(j))&&...
                    coord3(i)~=H1/2
                TabLink(i,j)=1;
            end
        end
    end


    %3 ��� ����������
elseif cube==3
    
    for i=1:N
        for j=1:N
            if (abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1)/L1)<0.0001||...
                    abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1*sqrt(2))/L1/sqrt(2))<0.0001&&coord1(i)>coord1(j)&&coord3(i)<coord3(j)&&coord2(i)==coord2(j))&&...
                    coord3(i)~=H1/2
                TabLink(i,j)=1;
            end
        end
    end
    
    %4 ��� ����������
elseif cube==4
    
    for i=1:N
        for j=1:N
            if (abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1)/L1)<0.0001||...
                    abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1*sqrt(2))/L1/sqrt(2))<0.0001&&coord2(i)==coord2(j))&&...
                    coord3(i)~=H1/2
                TabLink(i,j)=1;
            end
        end
    end
    
    %5 ��� ����������
elseif cube==5
    
    for i=1:N
        for j=1:N
            if (abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1)/L1)<0.0001||...
                    abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1*sqrt(2))/L1/sqrt(2))<0.0001&&coord1(i)>coord1(j)&&coord2(i)<coord2(j)&&coord3(i)==coord3(j))&&...
                    coord3(i)~=H1/2
                TabLink(i,j)=1;
            end
        end
    end
    
    %6 ��� ����������
elseif cube==6
    
    for i=1:N
        for j=1:N
            if (abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1)/L1)<0.0001||...
                    abs((sqrt((coord1(i)-coord1(j))^2+ ...
                    (coord2(i)-coord2(j))^2+ ...
                    (coord3(i)-coord3(j))^2) ...
                    -L1*sqrt(2))/L1/sqrt(2))<0.0001&&coord3(i)==coord3(j))&&...
                    coord3(i)~=H1/2
                TabLink(i,j)=1;
            end
        end
    end
    
end



%������ � �������� ���������

    G =TabLink;
    G=triu(G,1);
    [first,last]=find(G);
    T2=[first,last];
        
all=[coord1',coord2',coord3'];
Graph.nd=all;
Graph.ed=T2;
% Graph.RL=[Rad,Len];
% Graph.ni=NumIntLen;
Graph.vr2=[nLen,1,nW,Len,H,W,cube];

% (cube,nLen,nW,Len)



DateString=datestr(clock);
DateString(DateString==':')='_';
DateString(end-8:end)=[];
DateString=['CUB_',num2str(cube),'_',num2str(nLen),'_',num2str(nW),'_',num2str(Len)];
Graph.String=DateString;
save([DateString,'.mat'],'Graph');
toc
% (ro,a,expmu,sigma,MaxDeg,Rad,Len)


