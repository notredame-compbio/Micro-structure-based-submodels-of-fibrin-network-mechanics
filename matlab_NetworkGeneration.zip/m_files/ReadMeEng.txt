			Contents

		Network generators files

	RandomGraph.m 
	RegularGraph.m
	CylinderGraph.m
	CylinderGraph2.m
	SetDistribGraph.m 
	SetDistribGraph__OP.m
	WineRack.m
	CubeGraph.m

		Processing files

	GetParamGraph.m
	Plot3DGraph.m
	ConvertFormat.m
	ConvertFormat_MultiSelect.m
	NormStartFinish.m

		Notes



------------------------------------------------------------------------
	
	RandomGraph.m 

		Description
	
Generates random Erdos Renyi graph. The network is generated within closed volume limited by cylinder. 

		Parameters

Should be run using the following command:
RandomGraph(ro,P,r,l).

ro - density of nodes per unit of volume
P - probablity to create an edge (connection)
r - radius of the cylinder 
l - length of the cylinder (X axis)

		Example 

RandomGraph(0.5,0.005,4,20)

------------------------------------------------------------------------

	RegularGraph.m
	
		Description

	Generates Regular graph. The network is generated within closed volume limited by cylinder. 

		Parameters

RegularGraph(ro,k,r,l) 

ro - density of edges per unit of volume
k - desired degree of each node
r - radius of a cylinder
l - length of a cylinder  

		Example

RegularGraph(1,3,4,20)

------------------------------------------------------------------------

	CylinderGraph.m
	
		Description

Generates cylindrical network. 

		Parameters

CylinderGraph(nRad,nLen,nCircl,Rad,Len),

nRad - number of edges on the radius
nLen - number of edges on the length
nCircl - number of edges on the base circle
Rad - radius of a cylinder 
Len - length of a cylinder 

		Examples

CylinderGraph(5,5,5,2,10) % Creates .mat file with the graph data

GetParamGraph(CylinderGraph(5,5,5,2,10)) % Outputs graph information

Plot3DGraph(CylinderGraph(5,5,5,2,10))	% Generates 3D visualization of the network

------------------------------------------------------------------------

	CylinderGraph2.m
	
		Description

Generates cylindrical network. 

		Parameters

CylinderGraph2(nLen,nGrid,Rad,Len)

nGrid - grid size
nLen - number of edges on the length of a cylinder
Rad - radius of a cylinder 
Len - length of a cylinder 

		Examples

CylinderGraph2(2,8,3,10) % Creates .mat file with the graph data

GetParamGraph(CylinderGraph2(2,8,3,10)) % Outputs graph information

Plot3DGraph(CylinderGraph2(2,8,3,10))	% Generates 3D visualization of the network

------------------------------------------------------------------------

	SetDistribGraph.m 
	
		Description

Generates a graph with predefined log-normal edge length distribution and power law degree distribution. 

		Parameters

SetDistribGraph(ro,a,expmu,sigma,MaxDeg,Rad,Len) 

ro - edge density per unit of volume
a - power exponent for power law
expmu - mu for log-normal distribution 
sigma - sigma for log-normal distribution 
MaxDeg - maximum degree of a node, the amount of neighbors of a single node cannot exeed this value
Rad - radius of a cylinder 
Len - length of a cylinder % currently Len = Rad * 25, see note below

		Example

SetDistribGraph(0.05,1.5,2.15,0.7,30,4,10)

		Output 

Data-Param.m is created as an output 

		Note

In this algorythm lengths are being searched from either end of the cylinder. To change direction of length search in SetDistribGraph, one or another line should be commented:

for i=NumIntLen:-1:1 %variant1 % variant1 - searching for lengths from one end 
% for i=1:NumIntLen %variant2  % variant2 - searching for lengths from another end 

lines 94 and 95 in current version. 

This also applies to SetDistribGraph__OP.m


		Note 2

In this version parameter Len is equal to Rad * 25, regardless user's value. 

This can be changed on line 5: 
Len=Rad*25;

Also applies to SetDistribGraph__OP

------------------------------------------------------------------------
	
	SetDistribGraph__OP.m
	
		Description

Generates a graph with predefined parameters of:
	- order parameter (alignment metric)
	- degree distribution (power law)
	- edge length distribution (log-normal)

		Parameters

SetDistribGraph__OP(OP,coef,ro,a,expmu,sigma,MaxDeg,Rad,Len),

OP - desired Order Parameter. Takes values from 0 to 1, where 1 - perfectly aligned edges (x-axis direction), 0 - randomly chaotically oriented edges. 
coef - Order Parameter approximation coefficient. Takes values from 0 to 1, where 1 makes algorithm generate network with exact OP parameter value, and 0 makes algorithm do not consider OP value for network generation. In other words, this parameter defines importance of achieving specific OP.
ro - edge density per unit of volume
a - power exponent for power law
expmu - mu for log-normal distribution 
sigma - sigma for log-normal distribution 
MaxDeg - maximum degree of a node, the amount of neighbors of a single node cannot exeed this value
Rad - radius of a cylinder 
Len - length of a cylinder (X-axis direction)  % currently Len = Rad * 25, see note for SetDistribGraph

		Example

To check if a specific OP was reached GetParamGran can be used: 
GetParamGraph(SetDistribGraph__OP(0.6,1,4,1.5,5,0.7,10,2,50)) 


------------------------------------------------------------------------

	WineRack.m
	
		Description

 - generates Wine rack type network. 

		Parameters 

WineRack(nLen,nH,nW,Len,H,W)

nLen - number of or
nH - количество ребер по высоте,
nW - количество ребер по глубине,
Len - длина сети,
H - высота сети,
W - глубина сети.

		Examples
WineRack(3,3,1,10,5,5) % Creates .mat file with the graph data
или
GetParamGraph(WineRack(3,3,1,10,5,5)) % Outputs graph information
или
Plot3DGraph(WineRack(3,3,1,10,5,5)) % Generates 3D visualization of the network

------------------------------------------------------------------------

	CubeGraph.m
	
		Description

Generates differnet types of cubical networks. Each network is generated by replicating a cube of one chosen type. Each type of cube network differs from each other by its internal structure. 

		Parameters

CubeGraph(cube,nLen,nW,Len)

cube - cube structure type, takes values from 0 - 6, each value corresponds to different cube type. 
nLen - number of edges in length
nW - number of edges in width
Len - length of the network (width is calculated based on the relation of subcubes)

Cube types:

Cube = 0 - a cube with a node in the center. The node is connected to all 8 nodes of the cube. 
Cube = 1 - a cube with diagonal edges on top and bottom sides of the cube. 
Cube = 2 - a cube with only one diagonal edges on top and bottom sides of the cube.
Cube = 3 - a cube with only one diagonal edges on top and bottom sides of the cube (different direction).
Cube = 4 - a cube with both diagonal edges on the sides of the cube.
Cube = 5 - a cube with only one diagonal edges on right and left sides of the cube.
Cube = 6 - a cube with only one diagonal edges on right and left sides of the cube (different direction).

		Examples

CubeGraph(1,5,3,10) % Creates .mat file with the graph data

GetParamGraph(CubeGraph(1,5,3,10)) % Outputs graph information

Plot3DGraph(CubeGraph(1,5,3,10)) % Generates 3D visualization of the network

------------------------------------------------------------------------

	GetParamGraph.m
	
		Description

Calculates parameters of a generated network.  

		Examples

GetParamGraph(RandomGraph(0.5,0.005,4,20))

GetParamGraph(RegularGraph(1,5,4,20))

GetParamGraph(SetDistribGraph(0.05,1.5,2.15,0.7,30,4,10))

		Note

To process .mat files with GetParamGraph function, 'load' command should be used. 

load('Data.mat'); % loads contents of Data.mat to 'Graph'
GetParamGraph(Graph) % calculates parameters of the loaded network


------------------------------------------------------------------------

	Plot3DGraph.m
	
		Description

Visualisation tool. Builds 3D visulaisation of a generated graph. 

		Example

Plot3DGraph(SetDistribGraph(0.05,1.5,2.15,0.7,30,4,10))

Plot3DGraph(Graph) # where Graph is previously generated network. Variable Graph can be obtained by 'load' function. 


------------------------------------------------------------------------

	ConvertFormat.m
	
		Description

This scripts converts a txt file with specific format to the one that can be used with the WLC-bend model. This is used for experimental (KRM) files obtained by North Carolina research group. These files contain information about real experimental network. 

Format of these text files: 
node number,x,y,z,number of connections (degree),number of nodes this node has connections with

Sample line: 1,23,34,45,3,2,5,22 meaning node number one has coordinates 23,34,45, it has three connections with nodes 2, 5, 22. 

File with this format is converted to the network generation model format (.mat file).

The ouput .mat file can be analyzed and converted to .xml file to be used further with the model.

The initial network can be 'cut' by maximum coordinate to get desired proportions of the network.  

If the file has line in this form: 
1,23,34,45,3,2,5,22,77,66,33
meaning that the node has three connections with node 2 5 and 22, then the rest numbers 77 66 33 will be ignored. 

Dublicate connections and self connections are not considered. 

		Parameters

ConvertFormat(x,y,z)

x - maximum coordinate for x-axis
y - maximum coordinate for y-axis
z - maximum coordinate for z-axis

Limiting the maximum coordinate allows to split the network to desired size. 

After running the command the initial txt file should be chosen using the dialogue window.

		Examples:

ConvertFormat(200,200,200) % Creates .mat file with the graph data


GetParamGraph(ConvertFormat(200,200,200)) % Outputs graph information


Plot3DGraph(ConvertFormat(200,200,200)) % Generates 3D visualization of the network


------------------------------------------------------------------------

	ConvertFormat_MultiSelect.m
	
		Description

This script allows to chose multiple files for conversion from txt file described in ConvertFormat.m to .mat file. 

		Parameters 

ConvertFormat(x,y,z)

x - maximum coordinate for x-axis
y - maximum coordinate for y-axis
z - maximum coordinate for z-axis

------------------------------------------------------------------------

	NormStartFinish.m
	
		Description

Takes two files as an input *.start.layout and *.finish.layout and converts them to same scale, as if maximum coordinate for each of the file is equal to 1000. This allows to simplify visualisation process of initial and final network. 

	Parameters

NormStartFinish

the function doesn't have parameters. Entering the comand will open window to chose *.start.layout file and after that another window for chosing *.finish.layout file. 

After finishing the conversion two files are created in the directory of .layout files with "Norm_" at the beginning of the file names. 

------------------------------------------------------------------------

		Notes

1. To process .mat files with GetParamGraph and Plot3DGraph functions 'load' command should be used. 

		Example 

load('Data.mat'); % loads contents of Data.mat to 'Graph'
GetParamGraph(Graph) % calculates parameters of the loaded network
Plot3DGraph(Graph) % generates 3D visualization of the loaded network

2. After running GetParamGraph function an *.xml file is created beyond other files. The first several lines of this file is description of parameters that are later used for running the WLC-bend model. 

This list of parameters is set up in files "Settings.txt" and "force.txt". These files can be manually changed. .xml file can be changed after its creation as well. 








