%% function for create regular graph
function Graph=RegularGraph(ro,d,Rad,Len)
%ro - density of edges 
%d - number of edges
%Rx - max coordinate x
%Ry - max coordinate y
%Rz - max coordinate z
%Graph - output struct
%rl - real length

Volume=pi*Rad^2*Len;
Nr=round(Volume*ro);
N=round(2*Nr/d);
if mod(N,2)
    N=N+1;
end

% coeff=rl/max([Rx Ry Rz]);
% N=round(ro*Rx*Ry*Rz*coeff^3);
% Rx=coeff*Rx;
% Ry=coeff*Ry;
% Rz=coeff*Rz;
%% generate random coordinates of nodes
coord1=rand(1,N)*Len;
ang=rand(1,N)*2*pi;
rad=rand(1,N)*Rad;
coord2=Rad+real(rad.*exp(1j*ang));
coord3=Rad+imag(rad.*exp(1j*ang));

%% create 3D plot 
% figure
% 
% hold on
% for i=1:N
%     plot3(coord1(i),coord2(i),coord3(i),'o')
% end
% axis equal
%% create regular graph
T2=[];
if d<N
    G =createRandRegGraph(N,d);
    G=triu(G);
    [first,last]=find(G);
    T2=[first,last];
%     for i=1:length(first)
%         plot3([coord1(first(i)),coord1(last(i))],[coord2(first(i)),coord2(last(i))],[coord3(first(i)),coord3(last(i))])
%     end
end
% hold on;

%% output of function
all=[coord1',coord2',coord3'];
Graph.nd=all;
Graph.ed=T2;
Graph.RL=[Rad,Len];



% Graph.vr=[ro,d,Rad,Len];

DateString=datestr(clock);
DateString(DateString==':')='_';
DateString(end-8:end)=[];
DateString=['Regular_',num2str(ro),'_',num2str(d),num2str(Rad),'_',num2str(Len)];
Graph.String=DateString;
save([DateString,'.mat'],'Graph');
% Graph.rv=[Rx,Ry,Rz];