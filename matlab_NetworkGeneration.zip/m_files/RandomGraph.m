%% function for create random graph
function Graph=RandomGraph(ro,p,Rad,Len) 
%ro - density of nodes
%p - probability of creating an edge
%Rx - max coordinate x
%Ry - max coordinate y
%Rz - max coordinate z
%Graph - output struct
%rl - real length

% coeff=rl/max([Rx Ry Rz]);
% N=round(ro*Rx*Ry*Rz*coeff^3);
% Rx=coeff*Rx;
% Ry=coeff*Ry;
% Rz=coeff*Rz;
Volume=pi*Rad^2*Len;
N=round(Volume*ro);

%% generate random coordinates of nodes
coord1=rand(1,N)*Len;
ang=rand(1,N)*2*pi;
rad=rand(1,N)*Rad;
coord2=Rad+real(rad.*exp(1j*ang));
coord3=Rad+imag(rad.*exp(1j*ang));

% Rx=max(coord1);
% Ry=max(coord2);
% Rz=max(coord3);

%% first part of table - coordinates of nodes
T1=[cell(1,0),'nodes'];
for i=1:N
    T1=[T1;[num2str(i),' x =   ',num2str(coord1(i)),'     y =    ',num2str(coord2(i)),'     z =    ',num2str(coord3(i))]];
end

%% create 3D plot
% if N<=1000
%     figure
%     hold on
%     for i=1:N
%         plot3(coord1(i),coord2(i),coord3(i),'o')
%     end
%     axis equal
% end
%% Erdos Renyi algorithm
T2=[];
for i=1:N-1
    for j=i+1:N
        if rand<p
%             if N<=1000
%                 plot3([coord1(i),coord1(j)],[coord2(i),coord2(j)],[coord3(i),coord3(j)])
%             end
            T2=[T2;[i,j]];
        end
    end
end

%% output of function
all=[coord1',coord2',coord3'];
Graph.nd=all;
Graph.ed=T2;
Graph.RL=[Rad,Len];

DateString=datestr(clock);
DateString(DateString==':')='_';
DateString(end-8:end)=[];
DateString=['Random_',num2str(ro),'_',num2str(p),num2str(Rad),'_',num2str(Len)];
Graph.String=DateString;
save([DateString,'.mat'],'Graph');
% Graph.rv=[Rx,Ry,Rz];

