function Plot3DGraph(Graph)
all=Graph.nd;
coord1=all(:,1);
coord2=all(:,2);
coord3=all(:,3);
T2=Graph.ed;

N=size(all,1);

figure
axis equal
hold on
for i=1:N
    plot3(coord1(i),coord2(i),coord3(i),'o')
end
h=waitbar(0);
sc=0;
for i=1:size(T2,1)
    row=T2(i,1)';
    col=T2(i,2)';
    sc=sc+1;
    plot3([coord1(row),coord1(col)],[coord2(row),coord2(col)],[coord3(row),coord3(col)]);
%     pause(1);
    waitbar(sc/size(T2,1),h);
end
close(h)

