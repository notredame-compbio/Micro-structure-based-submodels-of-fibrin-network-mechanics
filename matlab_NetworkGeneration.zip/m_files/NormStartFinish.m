function NormStartFinish

[FileName1,PathName1] = uigetfile('*.*','Select Start File');
[FileName2,PathName2] = uigetfile('*.*','Select Finish File');
fileID = fopen([PathName1,FileName1],'r');
xT1=textscan(fileID,'%s','whitespace','\n');
fclose(fileID);
xT1=xT1{1,1};

op=cell(1,0);
po1=cell(1,0);
for i=1:length(xT1)
    now=xT1{i,1};
    if length(now)>12
        if strcmp(now(1:11),'//NODECOORD')
            op=[op;now(13:end)];
        else
            po1=[po1;now];
        end
    else
        po1=[po1;now];
    end
end

for i=1:length(op)
    now=op{i};
    sps=find(now==' ');
    sps=[0,sps,length(now)+1];
    for j=1:length(sps)-1
        allS(i,j)=str2double(now(sps(j)+1:sps(j+1)-1));
    end
end

fileID = fopen([PathName2,FileName2],'r');
xT2=textscan(fileID,'%s','whitespace','\n');
fclose(fileID);
xT2=xT2{1,1};

op=cell(1,0);
po2=cell(1,0);
for i=1:length(xT2)
    now=xT2{i,1};
    if length(now)>12
        if strcmp(now(1:11),'//NODECOORD')
            op=[op;now(13:end)];
        else
            po2=[po2;now];
        end
    else
        po2=[po2;now];
    end
end

for i=1:length(op)
    now=op{i};
    sps=find(now==' ');
    sps=[0,sps,length(now)+1];
    for j=1:length(sps)-1
        allF(i,j)=str2double(now(sps(j)+1:sps(j+1)-1));
    end
end

allS(:,1)=[];
allF(:,1)=[];

coeff=1000/max(max(allF));
allF=allF*coeff;
allS=allS*coeff;



lay=po1;
for i=1:size(allS,1)
    lay=[lay;['//NODECOORD ',num2str(i-1),' ',num2str((allS(i,1))),' ',num2str((allS(i,2))),' ',num2str((allS(i,3)))]];
end
fileID = fopen(['Norm_',FileName1],'w');
C=lay;
[nrows,~] = size(C);
formatSpec = '%s\n';
for row = 1:nrows
    fprintf(fileID,formatSpec,C{row,:});
end

lay=po2;
for i=1:size(allF,1)
    lay=[lay;['//NODECOORD ',num2str(i-1),' ',num2str((allF(i,1))),' ',num2str((allF(i,2))),' ',num2str((allF(i,3)))]];
end
fileID = fopen(['Norm_',FileName2],'w');
C=lay;
[nrows,~] = size(C);
formatSpec = '%s\n';
for row = 1:nrows
    fprintf(fileID,formatSpec,C{row,:});
end







