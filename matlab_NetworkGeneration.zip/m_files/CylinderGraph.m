%% function for create Cylinder graph
function Graph=CylinderGraph(nRad,nLen,nCircl,Rad,Len)
% close all;
tic

%calculate sizes
Nx=nLen+1;
Nyz=nCircl*nRad+1;
N=Nyz*Nx;

%create table of nodes links
TabLink=zeros(N,N);

%1 circle
coord01=0:Len/nLen:Len;
coord1=[];
coord2=[];
coord3=[];
for i=1:length(coord01)
    coord1=[coord1,ones(1,Nyz)*coord01(i)];
end
%angle
ang=0:2*pi/nCircl:2*pi-2*pi/nCircl;
%radius
rad=Rad/nRad:Rad/nRad:Rad;

coord02=[];
coord03=[];

nums=[2:nCircl,1];
% nRad circles
for i=1:nRad
    coord002=Rad+real(rad(i).*exp(1j*ang));
    coord003=Rad+imag(rad(i).*exp(1j*ang));
    
    coord02=[coord02,coord002];
    coord03=[coord03,coord003];
    
    ni=nCircl*(i-1);
    for j=1:nCircl
        TabLink(j+ni,nums(j)+ni)=1;
        TabLink(nums(j)+ni,j+ni)=1;
    end
end
coord02=[coord02,Rad];
coord03=[coord03,Rad];

% link nodes
for i=1:nRad
    for j=1:nCircl
        if i==1
            TabLink(length(coord02),j)=1;
            TabLink(j,length(coord02))=1;
        else
            TabLink(j+(i-1)*nCircl,j)=1;
            TabLink(j,j+(i-1)*nCircl)=1;
        end
    end
end


[xx,yy]=find(TabLink);

% yy2=[yy;max(yy)+1];
%���������� ���������� ������
yy2=yy;
for i=1:length(xx)
    for j=1:nLen
        TabLink(yy2(i)+(j-1)*Nyz,yy2(i)+j*Nyz)=1;
        TabLink(yy2(i)+j*Nyz,yy2(i)+(j-1)*Nyz)=1;
    end
end

for i=1:length(coord01)
    coord2=[coord2,coord02];
    coord3=[coord3,coord03];
    for j=1:length(xx)
        TabLink(xx(j)+(i-1)*Nyz,yy(j)+(i-1)*Nyz)=1;
        TabLink(yy(j)+(i-1)*Nyz,xx(j)+(i-1)*Nyz)=1;
    end
end


% plot3(coord1,coord2,coord3,'o');

% for i=1:


% ����� � �������� ��������
    G =TabLink;
    G=triu(G,1);
    [first,last]=find(G);
    T2=[first,last];
        
all=[coord1',coord2',coord3'];
Graph.nd=all;
Graph.ed=T2;
Graph.RL=[Rad,Len];
% Graph.ni=NumIntLen;
Graph.vr1=[nRad,nLen,nCircl,Rad,Len];

DateString=datestr(clock);
DateString(DateString==':')='_';
DateString(end-8:end)=[];
DateString=['C1_',num2str(nRad),'_',num2str(nLen),'_',num2str(nCircl),'_',num2str(Rad),'_',num2str(Len)];
Graph.String=DateString;
save([DateString,'.mat'],'Graph');
toc
% (ro,a,expmu,sigma,MaxDeg,Rad,Len)


