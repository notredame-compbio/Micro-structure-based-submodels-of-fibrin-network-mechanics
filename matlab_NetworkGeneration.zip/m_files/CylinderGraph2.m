%% function for create graph with specified distribution
function Graph=CylinderGraph2(nLen,nGrid,Rad,Len)
% close all;
tic
%calculate sizes
nRad=1;
nCircl=nGrid*4;

Nx=nLen+1;
Nyz=nCircl+nGrid^2;
N=Nyz*Nx;

%create table of nodes links
TabLink=zeros(N,N);

%1 circle
coord01=0:Len/nLen:Len;
coord1=[];
coord2=[];
coord3=[];
for i=1:length(coord01)
    coord1=[coord1,ones(1,Nyz)*coord01(i)];
end
%angle
if mod(nGrid,2)
    ang=0:2*pi/nCircl:2*pi-2*pi/nCircl;
else
    ang=pi/nCircl:2*pi/nCircl:2*pi-pi/nCircl;
end
%radius
rad=Rad/nRad:Rad/nRad:Rad;

coord02=[];
coord03=[];

nums=[2:nCircl,1];
% nRad circles
for i=1:nRad
    coord002=Rad+real(rad(i).*exp(1j*ang));
    coord003=Rad+imag(rad(i).*exp(1j*ang));
    
    coord02=[coord02,coord002];
    coord03=[coord03,coord003];
    
    ni=nCircl*(i-1);
    % link nodes
    for j=1:nCircl
    TabLink(j+ni,nums(j)+ni)=1;
    TabLink(nums(j)+ni,j+ni)=1;
    end
end
% coord02=[coord02,Rad];
% coord03=[coord03,Rad];

if mod(nGrid,2)
    points=[nCircl-(nGrid-1)/2+1:nCircl,1:nCircl-(nGrid-1)/2];
else
    points=[nCircl-nGrid/2+1:nCircl,1:nCircl-nGrid/2];
end

% for i=1:length(points)
%     
% end

[e,r]=meshgrid(coord02(points(nGrid+1:2*nGrid)),coord03(points(1:nGrid)));

    coord02=[coord02,e(:)'];
    coord03=[coord03,r(:)'];
    


[xx,yy]=find(TabLink);

% yy2=[yy;max(yy)+1];
yy2=[yy;(max(yy)+1:max(yy)+nGrid^2)'];


% index3=[];
% link nodes in Grid
for i=1:nGrid
    ind3=[];
    indx3=[];
    ind3=find(round(100000000*coord03(1:Nyz))/100000000==round(100000000*coord03(points(i)))/100000000);
    [~,indx3]=sort(coord02(ind3));
    for j=1:length(indx3)-1
        TabLink(ind3(indx3(j)),ind3(indx3(j+1)))=1;
        TabLink(ind3(indx3(j+1)),ind3(indx3(j)))=1;
    end
end


for i=nGrid+1:nGrid*2
    ind2=[];
    indx2=[];
    ind2=find(round(100000000*coord02(1:Nyz))/100000000==round(100000000*coord02(points(i)))/100000000);
    [~,indx2]=sort(coord03(ind2));
    for j=1:length(indx2)-1
        TabLink(ind2(indx2(j)),ind2(indx2(j+1)))=1;
        TabLink(ind2(indx2(j+1)),ind2(indx2(j)))=1;
    end
end

[xx,yy]=find(TabLink);

for i=1:length(coord01)
    coord2=[coord2,coord02];
    coord3=[coord3,coord03];
    for j=1:length(xx)
        TabLink(xx(j)+(i-1)*Nyz,yy(j)+(i-1)*Nyz)=1;
        TabLink(yy(j)+(i-1)*Nyz,xx(j)+(i-1)*Nyz)=1;
    end
end



yy2=unique(yy2);
for i=1:Nyz
    for j=1:nLen
        TabLink(yy2(i)+(j-1)*Nyz,yy2(i)+j*Nyz)=1;
        TabLink(yy2(i)+j*Nyz,yy2(i)+(j-1)*Nyz)=1;
    end
end

% figure
% plot3(coord1(1:11),coord2(1:11),coord3(1:11),'o');





G =TabLink;
G=triu(G,1);
[first,last]=find(G);
T2=[first,last];
        
all=[coord1',coord2',coord3'];
Graph.nd=all;
Graph.ed=T2;
Graph.RL=[Rad,Len];
% Graph.ni=NumIntLen;
Graph.vr2=[nRad,nLen,nCircl,Rad,Len];

DateString=datestr(clock);
DateString(DateString==':')='_';
DateString(end-8:end)=[];
DateString=['C2_',num2str(nLen),'_',num2str(nGrid),'_',num2str(Rad),'_',num2str(Len)];
Graph.String=DateString;
save([DateString,'.mat'],'Graph');
toc
% (ro,a,expmu,sigma,MaxDeg,Rad,Len)


